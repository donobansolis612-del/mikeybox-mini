-- Run only if you already deployed the original v0.1 schema with the 3-item CHECK constraint.
PRAGMA foreign_keys=off;
CREATE TABLE deliveries_new (
  id TEXT PRIMARY KEY,
  player_name TEXT NOT NULL,
  item_id TEXT NOT NULL,
  encrypted_room_code TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('awaiting_game_integration','cancelled')),
  idempotency_key TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL
);
INSERT INTO deliveries_new SELECT id,player_name,item_id,encrypted_room_code,status,idempotency_key,created_at FROM deliveries;
DROP TABLE deliveries;
ALTER TABLE deliveries_new RENAME TO deliveries;
CREATE INDEX IF NOT EXISTS deliveries_created_at ON deliveries(created_at);
PRAGMA foreign_keys=on;
