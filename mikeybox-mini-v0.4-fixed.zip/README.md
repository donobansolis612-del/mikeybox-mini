# MIKEYBOX MINI v0.3 — Expanded Catalog + My Inventions

Quest 3S/iPhone-friendly web prototype with a searchable Animal Company reference catalog, a 3D-style invention workspace, part hierarchy and transforms, local autosave, prototype JSON import/export, and an optional secure cloud delivery queue.

## What works now
- Search/filter an expanded community-referenced catalog covering regular items, special variants, event-only entries, removed entries, and unreleased/developer-only references.
- Save named player inventions to a local “My inventions” catalog, reopen them, and delete saved entries on the same browser/device.
- Create a root item and attach child items.
- Select, duplicate, delete, rename, parent, position, rotate and scale parts.
- See the part hierarchy and basic structural validation.
- Export/import `mikeybox-mini-goop` version 1 JSON and download project files.
- Autosave the current workspace in the browser's local storage.
- Optional Cloudflare Worker delivery request queue; room codes are encrypted before database storage.

## Important limitations
- The catalog is a broader community-reference list, not an official or complete game prefab manifest. It includes entries that may be removed, unreleased, developer-only, renamed, unobtainable, or not goopable. Catalog labels are not proof that an item can be spawned or used in a build. Names are not verified spawn IDs.
- “My inventions” are stored in browser local storage on the current device/browser; they do not automatically sync to the other device or cloud.
- The editor uses generic preview tiles, not extracted Animal Company meshes.
- The exported JSON is this prototype's own project format. It is NOT Mikeybox Goop JSON and is NOT a game-spawn package. The official editor's exact full serialization contract and item prefab IDs are not reproduced here.
- Delivery requests are queued with status `awaiting_game_integration`. The app does not join a room or spawn items. Real spawning requires an official game API or developer-approved plugin/SDK that can authenticate to a private room, validate the player and item, and invoke the game's spawn system.

## Sources and catalog notes
- Community item reference: https://officialanimalcompanyvr.fandom.com/wiki/Items
- Current Mikeybox Goop Editor guide: https://prime.mikeybox.ai/help (documents item browsing, verified collections, and the game-specific invention workflow).
- This prototype intentionally does not copy or claim the official Mikeybox serialization format or private prefab manifest.

## Deploy the static app
Host `index.html` on HTTPS using GitHub Pages, Cloudflare Pages, or another static host. Open the URL in Quest Browser or Safari on iPhone. The builder works locally without the cloud API.

## Deploy the optional Cloudflare API
1. Create a D1 database: `wrangler d1 create mikeybox-mini`.
2. Put its database ID in `wrangler.toml`.
3. Apply schema: `wrangler d1 execute mikeybox-mini --remote --file=./schema.sql`.
4. If upgrading an existing v0.1 database, run `migrations_0002_expand_catalog.sql` instead of reapplying the create schema.
5. Set secrets: `ADMIN_PIN`, `TOKEN_SECRET` (random 32+ characters), and `CODE_ENCRYPTION_KEY` (base64 encoding of exactly 32 random bytes).
6. Set `ALLOWED_ORIGIN` to the exact HTTPS origin serving the dashboard.
7. Deploy: `wrangler deploy`.
8. In Delivery Queue, enter the Worker URL and test the connection.

Never put secrets in the browser. Use HTTPS and configure rate limiting before public deployment.
