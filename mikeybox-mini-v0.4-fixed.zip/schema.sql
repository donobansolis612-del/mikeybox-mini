CREATE TABLE IF NOT EXISTS deliveries (
  id TEXT PRIMARY KEY,
  player_name TEXT NOT NULL,
  item_id TEXT NOT NULL,
  encrypted_room_code TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('awaiting_game_integration','cancelled')),
  idempotency_key TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS deliveries_created_at ON deliveries(created_at);
